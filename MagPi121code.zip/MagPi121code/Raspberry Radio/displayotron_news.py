# News display for Displayotron HAT
# From Raspberry Radio project in The MagPi by Sean McManus

import rr_newsreader
import time
import dot3k.backlight as backlight
import dot3k.lcd as lcd

def display_text(text):
    backlight.rgb(200, 200, 255)
    for i in range(min(len(text), 48)):
        substring = text[:i+1]
        lcd.clear()
        lcd.write(substring)
        time.sleep(0.1)
    backlight.rgb(255, 255, 255)
    time.sleep(3)

date_report = rr_newsreader.get_date()
display_text(date_report)

news_report = rr_newsreader.get_news()
for line in news_report:
    display_text(line)