# News display for Displayotron HAT
# From Raspberry Radio project in The MagPi by Sean McManus

import rr_newsreader
weather_report, temperature = rr_newsreader.get_weather()
print(weather_report)
date_report = rr_newsreader.get_date()
print(date_report)
news_report = rr_newsreader.get_news()
for line in news_report:
    print(line)